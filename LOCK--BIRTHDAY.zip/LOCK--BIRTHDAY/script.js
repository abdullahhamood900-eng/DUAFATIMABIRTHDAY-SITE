function checkPin() {

    const pin = document.getElementById("pin").value;
    const error = document.getElementById("error");

    if (pin === "1717") {

        error.style.color = "lime";
        error.innerHTML = "✅ Access Granted...";

        setTimeout(function () {
            window.location.href = "welcome/welcome.html";
        }, 1500);

    } else {

        error.style.color = "red";
        error.innerHTML = "❌ Wrong PIN";

        document.getElementById("pin").value = "";

    }

}

// Press Enter to Unlock
document.getElementById("pin").addEventListener("keypress", function(event) {

    if (event.key === "Enter") {
        checkPin();
    }

});